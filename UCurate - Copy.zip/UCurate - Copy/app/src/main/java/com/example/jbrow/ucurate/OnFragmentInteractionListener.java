package com.example.jbrow.ucurate;

/**
 * Created by charmipatel on 11/10/16.
 */

public interface OnFragmentInteractionListener {

    void onFragmentInteraction(int position);

}
